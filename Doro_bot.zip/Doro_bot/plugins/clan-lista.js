import fs from 'fs'
import path from 'path'
const DB_PATH = path.resolve('src/database/clanes.json')

function cargarClanes() {
    if (!fs.existsSync(DB_PATH)) return {}
    try { return JSON.parse(fs.readFileSync(DB_PATH, 'utf-8')) } catch { return {} }
}

let handler = async (m, { conn }) => {
    let clanes = cargarClanes()
    let out = Object.values(clanes).map(c =>
        `${c.emblema} *${c.nombre}* - ${c.descripcion} ${c.premium ? '🌟 (Premium)' : ''}\n` +
        `🏷️ Tipo: ${c.tipo || 'Aventureros'} | 🎨 Color: ${c.color || 'N/A'}\n` +
        `${c.logo ? '🖼️ Logo: ' + c.logo + '\n' : ''}${c.banner ? '🖼️ Banner: ' + c.banner + '\n' : ''}` +
        `👑 @${c.lider.split('@')[0]} | Miembros: ${c.miembros.length} | Nivel: ${c.nivel}\n`
    ).join('\n')
    m.reply('🌐 *Lista de clanes:*\n\n' + (out || 'No hay clanes.'))
}
handler.help = ['clan lista']
handler.tags = ['rpg']
handler.command = ['clan lista']

export default handler