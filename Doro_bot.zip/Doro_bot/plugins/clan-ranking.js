import fs from 'fs'
import path from 'path'
const DB_PATH = path.resolve('src/database/clanes.json')

function cargarClanes() {
    if (!fs.existsSync(DB_PATH)) return {}
    try { return JSON.parse(fs.readFileSync(DB_PATH, 'utf-8')) } catch { return {} }
}

let handler = async (m) => {
    let clanes = cargarClanes()
    let lista = Object.values(clanes)
        .sort((a, b) => (b.nivel - a.nivel) || (b.dinero - a.dinero))
        .map((c, i) => `${i+1}. ${c.emblema} *${c.nombre}* (Nivel ${c.nivel}, Dinero: ${c.dinero})`)
        .join('\n')
    m.reply('🏆 *Ranking de Clanes:*\n' + (lista || 'No hay clanes.'))
}
handler.help = ['clan ranking']
handler.tags = ['rpg']
handler.command = ['clan ranking']

export default handler