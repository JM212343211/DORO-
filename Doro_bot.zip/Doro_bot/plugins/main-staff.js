let handler = async (m, { conn, usedPrefix }) => {
    const menu = `
👥 *COLABORADORES DEL BOT* 👥

╭─────────────────────╮
┃ 🎖️ *CREADOR PRINCIPAL* 🎖️
╰─────────────────────╯

👑 **CREADORES DEL BOT**

┌──────────────────┐
│ 📱 +51 930 733 223
│ 🌐 github.com/JM212343211
│ ⭐ *Rol:* Fundador
└──────────────────

┌──────────────────┐
│ 📱 +52 418 145 0063
│ 🌐 github.com/Fer280809
│ ⭐ *Rol:* Fundador
└──────────────────┘

🤖 **DORO_BOT FERNANDO**
┌──────────────────┐
│ 📱 +51 927 917 562
│ 🎯 *Rol:* Bot oficial
└──────────────────┘

╭───────────────╮
┃ 🔥 *DESARROLLADORES* 🔥
╰───────────────╯

🚀 **Fernando**
📱 +52 746 117 7130
🌐 github.com/Fer280809
⚡ Desarrollo de comandos



╭────────────────╮
┃ 🌟 *RESUMEN* 🌟
╰────────────────╯

📊 *Equipo:*
• 👑 2 Creador
• 🤖 1 Bot oficial
• 💻 1 Desarrolladores

╭────────────────╮
┃ 🚀 *¿SER DEVELOPER?* 🚀
╰────────────────╯

💡 *¡Únete al equipo!*

📝 *Aplica aquí:*
https://surveyheart.com/form/6835fa3f543db626e9bdd8a2

⚠️ *IMPORTANTE:*
• Usa información REAL
• El creador te contactará
• Buscamos talento comprometido

_Desarrollado con ❤️ por el equipo_
    `
    m.reply(menu)
}

handler.tags = ['info', 'staff']
handler.help = ['colaboradores', 'staff', 'equipo']
handler.command = ['colaboradores', 'staff', 'equipo', 'team', 'devs']
handler.group = false

export default handler
