let handler = async (m, { conn }) => {
  let menu = `
👑 *MENÚ DE CLANES - REINOS DE SOMBRAS* 👑

Crea, gestiona y haz crecer tu propio clan con estos comandos:

🛡️ *Comandos de Clan:*

• clan crear <nombre>      ➤ Crea un nuevo clan
• clan unirse <nombre>     ➤ Solicita unirte a un clan
• clan salir               ➤ Sal de tu clan actual
• clan expulsar <@usuario> ➤ Expulsa a un miembro (solo líder)
• clan ascender <@usuario> ➤ Asciende a sublíder (solo líder)
• clan degradar <@usuario> ➤ Quita sublíder (solo líder)
• clan transferir <@usuario> ➤ Transfiere el liderazgo (solo líder)
• clan lista               ➤ Muestra la lista de miembros
• clan info                ➤ Muestra información detallada del clan
• clan chat <mensaje>      ➤ Envía un mensaje al chat del clan
• clan ranking             ➤ Lista los clanes por puntos/poder
• clan ayuda               ➤ Muestra este menú de ayuda

*Ejemplo:* 
.clan crear LosAventureros

¡Forma tu clan, invita amigos y dominen el Reino de las Sombras!
`.trim()
  await conn.reply(m.chat, menu, m)
}
handler.command = ['clan', 'clanes', 'clanmenu', 'clanhelp']

export default handler
