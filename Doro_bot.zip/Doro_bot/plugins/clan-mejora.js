import fs from 'fs'
import path from 'path'
const DB_PATH = path.resolve('src/database/clanes.json')

function cargarClanes() {
    if (!fs.existsSync(DB_PATH)) return {}
    try { return JSON.parse(fs.readFileSync(DB_PATH, 'utf-8')) } catch { return {} }
}
function guardarClanes(clanes) {
    fs.mkdirSync(path.dirname(DB_PATH), { recursive: true })
    fs.writeFileSync(DB_PATH, JSON.stringify(clanes, null, 2))
}

const MEJORAS_COSTO = {
    vida: 1000,
    fuerza: 1200,
    dinero: 800,
    especial: 4000
}

let handler = async (m, { args, isOwner }) => {
    let clanes = cargarClanes()
    let user = global.db.data.users[m.sender]
    if (!user || !user.clan) return m.reply('❌ No perteneces a ningún clan.')
    let clan = clanes[user.clan]
    if (!clan) return m.reply('❌ Clan no encontrado.')
    if (clan.lider !== m.sender && !isOwner) return m.reply('❌ Solo el líder o owner puede mejorar el clan.')
    let mejora = (args[0] || '').toLowerCase()
    if (!['vida','fuerza','dinero','especial'].includes(mejora)) return m.reply('❌ Mejora inválida. Usa: vida, fuerza, dinero' + (clan.premium ? ', especial' : ''))
    if (mejora === 'especial' && !clan.premium) return m.reply('❌ Solo clanes premium pueden mejorar especial.')
    let costo = MEJORAS_COSTO[mejora]
    if (clan.dinero < costo) return m.reply(`❌ El clan no tiene suficiente dinero para mejorar ${mejora}. Requiere ${costo}.`)
    clan.dinero -= costo
    clan.mejoras[mejora] = (clan.mejoras[mejora] || 0) + 1
    guardarClanes(clanes)
    m.reply(`✅ Mejora realizada: ${mejora} (${clan.mejoras[mejora]})\n💰 Dinero restante del clan: ${clan.dinero}`)
}
handler.help = ['clan mejorar <vida|fuerza|dinero|especial>']
handler.tags = ['rpg']
handler.command = ['clan mejorar']

export default handler


