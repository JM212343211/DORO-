import fs from 'fs'
import path from 'path'
const DB_PATH = path.resolve('src/database/clanes.json')

function cargarClanes() {
    if (!fs.existsSync(DB_PATH)) return {}
    try { return JSON.parse(fs.readFileSync(DB_PATH, 'utf-8')) } catch { return {} }
}
function guardarClanes(clanes) {
    fs.mkdirSync(path.dirname(DB_PATH), { recursive: true })
    fs.writeFileSync(DB_PATH, JSON.stringify(clanes, null, 2))
}

let handler = async (m, { conn, args }) => {
    let clanes = cargarClanes()
    let user = global.db.data.users[m.sender]
    if (!user) return m.reply('❌ Usa !comenzar para iniciar en el sistema RPG.')
    let name = args.join(' ')
    let clanId = Object.keys(clanes).find(id => clanes[id].nombre?.toLowerCase() === name.toLowerCase())
    if (!clanId) return m.reply('❌ Clan no encontrado.')
    if (user.clan) return m.reply('❌ Ya perteneces a un clan. Sal primero con !clan salir')
    if (clanes[clanId].miembros.includes(m.sender)) return m.reply('❌ Ya eres miembro de este clan.')
    clanes[clanId].miembros.push(m.sender)
    user.clan = clanId
    guardarClanes(clanes)
    m.reply(`Has entrado al clan *${clanes[clanId].nombre}*`)
}
handler.help = ['clan unirse <nombre>']
handler.tags = ['rpg']
handler.command = ['clan unirse']

export default handler

