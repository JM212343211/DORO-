import fs from 'fs'
import path from 'path'
const DB_PATH = path.resolve('src/database/clanes.json')

function cargarClanes() {
    if (!fs.existsSync(DB_PATH)) return {}
    try { return JSON.parse(fs.readFileSync(DB_PATH, 'utf-8')) } catch { return {} }
}
function guardarClanes(clanes) {
    fs.mkdirSync(path.dirname(DB_PATH), { recursive: true })
    fs.writeFileSync(DB_PATH, JSON.stringify(clanes, null, 2))
}

let handler = async (m) => {
    let clanes = cargarClanes()
    let user = global.db.data.users[m.sender]
    if (!user || !user.clan) return m.reply('❌ No estás en ningún clan.')
    let clan = clanes[user.clan]
    if (!clan) {
        user.clan = null
        return m.reply('❌ El clan ya no existe.')
    }
    clan.miembros = clan.miembros.filter(u => u !== m.sender)
    if (clan.lider === m.sender) {
        if (clan.miembros.length === 0) {
            delete clanes[user.clan]
            user.clan = null
            guardarClanes(clanes)
            return m.reply('El clan ha sido eliminado porque no quedan miembros.')
        }
        clan.lider = clan.miembros[0]
    }
    user.clan = null
    guardarClanes(clanes)
    m.reply('Has salido del clan.')
}
handler.help = ['clan salir']
handler.tags = ['rpg']
handler.command = ['clan salir']

export default handler

