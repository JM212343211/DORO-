 /** Mute temporal y permanente para grupos
 * By @MoonContentCreator - Mejorado por Fer280809
 */

let muteTimers = global.muteTimers || (global.muteTimers = {});

const parseDuration = (str) => {
    let match = str.match(/^(\d+)([mhds]|mo)$/i);
    if (!match) return null;
    let num = parseInt(match[1]);
    let type = match[2].toLowerCase();
    switch (type) {
        case "m": return num * 60 * 1000;
        case "h": return num * 60 * 60 * 1000;
        case "d": return num * 24 * 60 * 60 * 1000;
        case "s": return num * 1000;
        case "mo": return num * 30 * 24 * 60 * 60 * 1000;
        default: return null;
    }
};

let handler = async (m, { conn, command, args, isBotAdmin, groupMetadata }) => {
    if (!m.isGroup) throw 'Este comando solo funciona en grupos';
    if (!isBotAdmin) throw 'Necesito permisos de admin para mutear el grupo';

    let chat = global.db.data.chats[m.chat];
    if (!chat) global.db.data.chats[m.chat] = chat = {};

    // mute [duración]
    if (command === 'mute') {
        let duration = args[0] ? parseDuration(args[0]) : null;
        if (chat.isMute) return m.reply('❌ El grupo ya está muteado.');

        chat.isMute = true;
        chat.muteExpire = duration ? Date.now() + duration : null;

        await conn.groupSettingUpdate(m.chat, 'announcement');
        if (duration) {
            // Programar desmute automático
            if (muteTimers[m.chat]) clearTimeout(muteTimers[m.chat]);
            muteTimers[m.chat] = setTimeout(async () => {
                chat.isMute = false;
                chat.muteExpire = null;
                await conn.groupSettingUpdate(m.chat, 'not_announcement');
                await conn.sendMessage(m.chat, { text: '🔊 El grupo ha sido desmuteado automáticamente.' });
            }, duration);

            let tiempo = args[0].replace('mo', ' meses').replace('d', ' días').replace('h', ' horas').replace('m', ' minutos').replace('s', ' segundos');
            return m.reply(`🔇 El grupo ha sido muteado por ${tiempo}.`);
        } else {
            return m.reply('🔇 El grupo ha sido muteado indefinidamente. Usa !unmute para desmutear.');
        }
    }

    // unmute
    if (command === 'unmute') {
        if (!chat.isMute) return m.reply('🔊 El grupo ya está activo.');
        chat.isMute = false;
        chat.muteExpire = null;
        await conn.groupSettingUpdate(m.chat, 'not_announcement');
        if (muteTimers[m.chat]) clearTimeout(muteTimers[m.chat]);
        return m.reply('🔊 El grupo ha sido desmuteado.');
    }

    // mutestatus
    if (command === 'mutestatus') {
        if (!chat.isMute) return m.reply('🔊 El grupo no está muteado.');
        if (chat.muteExpire) {
            let ms = chat.muteExpire - Date.now();
            if (ms <= 0) return m.reply('🔊 El grupo está a punto de ser desmuteado.');
            let mins = Math.floor(ms / 60000) % 60;
            let hours = Math.floor(ms / 3600000) % 24;
            let days = Math.floor(ms / 86400000);
            let meses = Math.floor(days / 30); days = days % 30;
            let partes = [];
            if (meses) partes.push(`${meses} mes(es)`);
            if (days) partes.push(`${days} día(s)`);
            if (hours) partes.push(`${hours} hora(s)`);
            if (mins) partes.push(`${mins} minuto(s)`);
            m.reply('⏳ Tiempo restante mute: ' + partes.join(', '));
        } else {
            m.reply('🔇 El grupo está muteado indefinidamente.');
        }
    }
};

handler.help = ['mute [10m|2h|1d|1mo]', 'unmute', 'mutestatus'];
handler.tags = ['group', 'admin'];
handler.command = ['mute', 'unmute', 'mutestatus']; // <---- AQUÍ el formato correcto
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

export default handler;
