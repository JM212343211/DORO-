import fs from 'fs'
import path from 'path'
const DB_PATH = path.resolve('src/database/clanes.json')

function cargarClanes() {
    if (!fs.existsSync(DB_PATH)) return {}
    try { return JSON.parse(fs.readFileSync(DB_PATH, 'utf-8')) } catch { return {} }
}

let handler = async (m) => {
    let clanes = cargarClanes()
    let user = global.db.data.users[m.sender]
    if (!user || !user.clan) return m.reply('❌ No perteneces a ningún clan.')
    let clan = clanes[user.clan]
    let lg = clan.logrosData
    m.reply(
        `🏅 *Logros de clan*\n` +
        `🏆 Victorias: ${lg.victorias}\n` +
        `💀 Derrotas: ${lg.derrotas}\n` +
        `💸 Donaciones: ${lg.donaciones}\n` +
        `🎁 Cofres abiertos: ${lg.cofres}\n` +
        `🔧 Mejoras compradas: ${lg.mejoras}`
    )
}
handler.help = ['clan logros']
handler.tags = ['rpg']
handler.command = ['clan logros']

export default handler