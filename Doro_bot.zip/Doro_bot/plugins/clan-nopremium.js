import fs from 'fs'
import path from 'path'
const DB_PATH = path.resolve('src/database/clanes.json')

function cargarClanes() {
    if (!fs.existsSync(DB_PATH)) return {}
    try { return JSON.parse(fs.readFileSync(DB_PATH, 'utf-8')) } catch { return {} }
}
function guardarClanes(clanes) {
    fs.mkdirSync(path.dirname(DB_PATH), { recursive: true })
    fs.writeFileSync(DB_PATH, JSON.stringify(clanes, null, 2))
}

let handler = async (m, { args, isOwner }) => {
    if (!isOwner) return m.reply('❌ Solo el owner puede usar este comando.')
    let clanes = cargarClanes()
    let clanName = args.join(' ')
    let clanId = Object.keys(clanes).find(id => clanes[id].nombre?.toLowerCase() === clanName.toLowerCase())
    if (!clanId) return m.reply('❌ Clan no encontrado.')
    clanes[clanId].premium = false
    guardarClanes(clanes)
    m.reply(`✨ El clan *${clanes[clanId].nombre}* ahora es NORMAL.`)
}
handler.help = ['clan nopremium <nombre>']
handler.tags = ['rpg']
handler.command = ['clan nopremium']

export default handler