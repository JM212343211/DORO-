import fs from 'fs'
import path from 'path'
const DB_PATH = path.resolve('src/database/clanes.json')

function cargarClanes() {
  if (!fs.existsSync(DB_PATH)) return {}
  try { return JSON.parse(fs.readFileSync(DB_PATH, 'utf-8')) } catch { return {} }
}
function guardarClanes(clanes) {
  fs.mkdirSync(path.dirname(DB_PATH), { recursive: true })
  fs.writeFileSync(DB_PATH, JSON.stringify(clanes, null, 2))
}

function poderTotal(clan) {
  let base = (clan.nivel * 10) + (clan.mejoras.vida * 30) + (clan.mejoras.fuerza * 50) + (clan.mejoras.dinero * 10)
  if (clan.premium) base += (clan.mejoras.especial || 0) * 80
  return base + (clan.miembros?.length || 0) * 10
}

let handler = async (m, { args, isOwner }) => {
  let clanes = cargarClanes()
  let user = global.db.data.users[m.sender]
  if (!user || !user.clan) return m.reply('❌ No perteneces a ningún clan.')
  let clan = clanes[user.clan]
  if (!clan) return m.reply('❌ Clan no encontrado.')
  let nombreRival = args.join(' ')
  if (!nombreRival) return m.reply('❌ Debes indicar el nombre del clan rival. Ejemplo: !clan luchar Dragones')
  let rivalId = Object.keys(clanes).find(id => clanes[id].nombre?.toLowerCase() === nombreRival.toLowerCase())
  if (!rivalId || rivalId === user.clan) return m.reply('❌ Clan rival no encontrado o no puedes luchar contra tu propio clan.')
  let rival = clanes[rivalId]

  // Simulación de combate
  let poder1 = poderTotal(clan)
  let poder2 = poderTotal(rival)

  // Recompensa y penalización
  let premio = 600 + Math.floor(Math.random() * 800)
  let perdida = 300 + Math.floor(Math.random() * 400)

  let resultado = ''
  if (poder1 === poder2) {
    resultado = '¡Empate! Ambos clanes están igualados en poder.'
  } else if (poder1 > poder2) {
    clan.logrosData.victorias += 1
    rival.logrosData.derrotas += 1
    clan.dinero += premio
    rival.dinero = Math.max(0, rival.dinero - perdida)
    resultado = `🎉 ¡Tu clan *${clan.nombre}* ha ganado la batalla!\n+${premio} monedas para tu clan.\nEl clan rival pierde ${perdida}.`
  } else {
    rival.logrosData.victorias += 1
    clan.logrosData.derrotas += 1
    rival.dinero += premio
    clan.dinero = Math.max(0, clan.dinero - perdida)
    resultado = `😢 El clan rival *${rival.nombre}* ha ganado la batalla.\n+${premio} monedas para el rival.\nTu clan pierde ${perdida}.`
  }
  guardarClanes(clanes)
  m.reply(`⚔️ *Batalla de clanes*\n\n${clan.nombre} (${poder1} poder) VS ${rival.nombre} (${poder2} poder)\n\n${resultado}\n\n💰 Dinero de tu clan: ${clan.dinero}\n💰 Dinero del rival: ${rival.dinero}`)
}
handler.help = ['clan luchar <nombre del clan rival>']
handler.tags = ['rpg']
handler.command = ['clan luchar']

export default handler

